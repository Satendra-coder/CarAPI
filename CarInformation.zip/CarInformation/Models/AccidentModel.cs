﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarInformation.Models
{
    public class AccidentModel
    {
        public string AccidentType { get; set; }
        public DateTime AccidentDate { get; set; }
    }
}